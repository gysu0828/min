package egov.mywork1.service;

import java.util.List;

public interface AdminService {

	String insertNotice(NoticeVO vo) throws Exception;
	List<?> selectNoticeList(DefaultVO vo) throws Exception;
	int selectNoticeTotal(DefaultVO vo) throws Exception;
	NoticeVO selectNoticeDetail(String unq) throws Exception;
	int updateNoticeHits(String unq) throws Exception;
	int adminNoticeUpdate(NoticeVO vo) throws Exception;
	int adminNoticeDelete(NoticeVO vo) throws Exception;
	
	//	일반회원목록
	List<?> selectMemberList(DefaultVO vo) throws Exception;
	//  회원총개수
	int selectMemberTotal(DefaultVO vo) throws Exception;
	
	//회원상세
	MemberVO selectMemberDetail(String userid) throws Exception;
	
	//회원수정처리
	int updateMemberSave(MemberVO vo) throws Exception;
	//회원삭체처리
	int deleteMemberUser(String userid) throws Exception;
}

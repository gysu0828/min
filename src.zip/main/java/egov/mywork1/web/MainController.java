package egov.mywork1.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import egov.mywork1.service.DefaultVO;
import egov.mywork1.service.NoticeVO;
import egov.mywork1.service.AdminService;

@Controller
public class MainController {
	
	
	@RequestMapping("/index.do")
	public String index() { /* 익셉션처리 노 */
		return "index";
	}
	
	@RequestMapping("/main.do")
	public String main() {
		return "main/main";
	}
	
	
	
	
}

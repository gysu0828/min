package egov.mywork1.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractDAO;
import org.springframework.stereotype.Repository;

import egov.mywork1.service.MobileVO;



@Repository("mobileDAO")
public class MobileDAO extends EgovAbstractDAO {

	public String insertMobile(MobileVO vo) {
		
		return (String) insert("mobileDAO.insertMobile",vo);
		
	}

	public List<?> selectMobileList(MobileVO vo) {
		
		return list("mobileDAO.selectMobileList",vo);
		
	}
	
	public List<?> selectMobileListDetail(MobileVO vo) {
		
		return list("mobileDAO.selectMobileListDetail",vo);
	}

	
	public int deleteMobile(MobileVO vo) {
		
		return delete("mobileDAO.deleteMobile",vo);
		
	}
	
	
	public int selectMaxMonum(MobileVO vo) {
		
		return (int) select("mobileDAO.selectMaxMonum",vo);
		
	}

}

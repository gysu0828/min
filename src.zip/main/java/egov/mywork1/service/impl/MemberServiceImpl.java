package egov.mywork1.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.mywork1.service.MemberService;
import egov.mywork1.service.MemberVO;

@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Resource(name = "memberDAO")
	MemberDAO memberDAO;
	
	@Override
	public String insertMember(MemberVO vo) throws Exception {
		
		return memberDAO.insertMember(vo);
	}

	@Override
	public int selectMemberUserid(String userid) throws Exception {
		
		return memberDAO.selectMemberUserid(userid);
	}

	@Override
	public int selectMemberNickname(String nickname) throws Exception {
		
		return memberDAO.selectMemberNickname(nickname);
	}

	@Override
	public String selectMemberLogin(MemberVO vo) throws Exception {

		return memberDAO.selectMemberLogin(vo);
	}

	@Override
	public MemberVO selectMemberDetail(String userid) {
		
		return memberDAO.selectMemberDetail(userid);
	}

	@Override
	public int updateMember(MemberVO vo) {
		
		return memberDAO.updateMember(vo);
	}

	@Override
	public String selectPreventName(int no) throws Exception {
		
		return memberDAO.selectPreventName(no);
	}

	@Override
	public String selectMemberUseridReturn(MemberVO vo) throws Exception {
		
		return memberDAO.selectMemberUseridReturn(vo);
	}

	@Override
	public int selectMemberExistCount(MemberVO vo) throws Exception {
		
		return memberDAO.selectMemberExistCount(vo);
	}

	@Override
	public void updateMemberPass(MemberVO vo) throws Exception {
		
		memberDAO.updateMemberPass(vo);
	}

	@Override
	public int updateMemberPassChange(Map<String, String> map) throws Exception {
		
		return memberDAO.updateMemberPassChange(map);
	}

	@Override
	public String selectMemberState(String userid) throws Exception {

		return memberDAO.selectMemberState(userid);
	}

	/*
	 * @Override public int selectMemberNicknameCHK(MemberVO vo) {
	 * 
	 * return memberDAO.selectMemberNicknameCHK(vo); }
	 */

}

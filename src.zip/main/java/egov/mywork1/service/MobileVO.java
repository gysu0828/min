package egov.mywork1.service;

public class MobileVO {
	private int monum;
	private String moname;
	private String moclass;
	private String mordate;
	private String mocon;
	private String moprice;
	
	public int getMonum() {
		return monum;
	}
	public void setMonum(int monum) {
		this.monum = monum;
	}
	public String getMoname() {
		return moname;
	}
	public void setMoname(String moname) {
		this.moname = moname;
	}
	public String getMoclass() {
		return moclass;
	}
	public void setMoclass(String moclass) {
		this.moclass = moclass;
	}
	public String getMordate() {
		return mordate;
	}
	public void setMordate(String mordate) {
		this.mordate = mordate;
	}
	public String getMocon() {
		return mocon;
	}
	public void setMocon(String mocon) {
		this.mocon = mocon;
	}
	public String getMoprice() {
		return moprice;
	}
	public void setMoprice(String moprice) {
		this.moprice = moprice;
	}
	
	
	
	
	
}

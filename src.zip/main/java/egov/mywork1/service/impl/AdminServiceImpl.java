package egov.mywork1.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.mywork1.service.AdminService;
import egov.mywork1.service.DefaultVO;
import egov.mywork1.service.MemberVO;
import egov.mywork1.service.NoticeVO;

@Service("adminService")
public class AdminServiceImpl implements AdminService {

	@Resource(name =  "adminDAO")
	AdminDAO adminDAO;
	
	@Override
	public String insertNotice(NoticeVO vo) throws Exception {
				
		return adminDAO.insertNotice(vo);
	}

	@Override
	public List<?> selectNoticeList(DefaultVO vo) throws Exception {
		
		return adminDAO.selectNoticeList(vo);
	}

	@Override
	public int selectNoticeTotal(DefaultVO vo) throws Exception {
		
		return adminDAO.selectNoticeTotal(vo);
	}

	@Override
	public NoticeVO selectNoticeDetail(String unq) throws Exception {
		
		return adminDAO.selectNoticeDetail(unq);
	}

	@Override
	public int updateNoticeHits(String unq) throws Exception {
		
		return adminDAO.updateNoticeHits(unq);
	}

	@Override
	public int adminNoticeDelete(NoticeVO vo) throws Exception {
		
		return adminDAO.adminNoticeDelete(vo);
	}

	@Override
	public int adminNoticeUpdate(NoticeVO vo) throws Exception {
		
		return adminDAO.adminNoticeUpdate(vo);
	}

	@Override
	public List<?> selectMemberList(DefaultVO vo) throws Exception {
		
		return adminDAO.selectMemberList(vo);
	}

	@Override
	public int selectMemberTotal(DefaultVO vo) throws Exception {

		return adminDAO.selectMemberTotal(vo);
	}

	@Override
	public MemberVO selectMemberDetail(String userid) throws Exception {
	
		return adminDAO.selectMemberDetail(userid);
	}

	@Override
	public int updateMemberSave(MemberVO vo) throws Exception {

		return adminDAO.updateMemberSave(vo);
	}

	@Override
	public int deleteMemberUser(String userid) throws Exception {

		return adminDAO.deleteMemberUser(userid);
	}

}

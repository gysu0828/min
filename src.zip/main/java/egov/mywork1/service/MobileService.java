package egov.mywork1.service;

import java.util.List;

public interface MobileService {

	public int selectMaxMonum(MobileVO vo) throws Exception;
	
	public String insertMobile(MobileVO vo) throws Exception;
	
	public List<?> selectMobileList(MobileVO vo) throws Exception;
	
	public List<?> selectMobileListDetail(MobileVO vo) throws Exception;
	
	int deleteMobile(MobileVO vo) throws Exception;
	
	
	
}

package egov.mywork1.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egov.mywork1.service.MobileService;
import egov.mywork1.service.MobileVO;

@Service("mobileService")
public class MobileServiceImpl implements MobileService {

	@Resource(name = "mobileDAO")
	MobileDAO mobileDAO;

	@Override
	public String insertMobile(MobileVO vo) throws Exception {
		
		return mobileDAO.insertMobile(vo);
	}

	@Override
	public List<?> selectMobileList(MobileVO vo) throws Exception {
		
		return mobileDAO.selectMobileList(vo);
	}
	
	@Override
	public List<?> selectMobileListDetail(MobileVO vo) throws Exception {
		
		return mobileDAO.selectMobileListDetail(vo);
	}

	@Override
	public int deleteMobile(MobileVO vo) throws Exception {
		
		return mobileDAO.deleteMobile(vo);
	}
	
	@Override
	public int selectMaxMonum(MobileVO vo) throws Exception {
		
		return mobileDAO.selectMaxMonum(vo);
	}

}

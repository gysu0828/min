package egov.mywork1.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractDAO;
import org.springframework.stereotype.Repository;

import egov.mywork1.service.DefaultVO;
import egov.mywork1.service.MemberVO;
import egov.mywork1.service.NoticeVO;

@Repository("adminDAO")
public class AdminDAO extends EgovAbstractDAO {

	public String insertNotice(NoticeVO vo) {
		
		return (String) insert("adminDAO.insertNotice",vo);
	}

	public List<?> selectNoticeList(DefaultVO vo) {
		
		return list("adminDAO.selectNoticeList",vo);
	}

	public int selectNoticeTotal(DefaultVO vo) {
		
		return (int) select("adminDAO.selectNoticeTotal",vo);
	}

	public NoticeVO selectNoticeDetail(String unq) {
		
		return (NoticeVO) select("adminDAO.selectNoticeDetail",unq);
	}

	public int updateNoticeHits(String unq) {
		
		return update("adminDAO.updateNoticeHits",unq);
	}

	public int adminNoticeDelete(NoticeVO vo) {
		
		return delete("adminDAO.adminNoticeDelete",vo);
	}

	public int adminNoticeUpdate(NoticeVO vo) {
		
		return update("adminDAO.adminNoticeUpdate",vo);
	}

	public List<?> selectMemberList(DefaultVO vo) {
		
		return list("adminDAO.selectMemberList",vo);
	}

	public int selectMemberTotal(DefaultVO vo) {

		return (int) select("adminDAO.selectMemberTotal",vo);
	}

	public MemberVO selectMemberDetail(String userid) {

		return (MemberVO) select("adminDAO.selectMemberDetail",userid);
	}

	public int updateMemberSave(MemberVO vo) {

		return update("adminDAO.updateMemberSave",vo);
	}

	public int deleteMemberUser(String userid) {

		return delete("adminDAO.deleteMemberUser",userid);
	}

}

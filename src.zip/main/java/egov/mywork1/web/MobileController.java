package egov.mywork1.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import egov.mywork1.service.MobileService;
import egov.mywork1.service.MobileVO;


@Controller
public class MobileController {

	@Resource(name = "mobileService")
	MobileService mobileService;
	
	@RequestMapping("/mobileWrite.do")
	public String mobileWrite(MobileVO vo,ModelMap model) throws Exception {
		
		int monum = mobileService.selectMaxMonum(vo);
		model.addAttribute("monum", monum);
		
		return "mobile/mobileWrite";
	}
	
	
	@RequestMapping("/mobileWriteSave.do")
	@ResponseBody
	public String insertMobile(MobileVO vo) throws Exception {	
		
		String result =mobileService.insertMobile(vo);
		String str = (result==null)?"ok":"fail";		
		return str;
	}
	
	@RequestMapping("/mobileList.do")
	public String selectMobileList(MobileVO vo,ModelMap model) throws Exception {
		
		List<?> list = mobileService.selectMobileList(vo);
		model.addAttribute("resultList",list);
		model.addAttribute("MobileVO", vo);
		return "mobile/mobileList";
	}
	
	@RequestMapping("/mobileList2.do")
	public String selectMobileListDetail(MobileVO vo,ModelMap model) throws Exception {
		
		List<?> list = mobileService.selectMobileListDetail(vo);
		model.addAttribute("resultList",list);
		model.addAttribute("MobileVO", vo);
		
		return "mobile/mobileList2";
	}
	
	@RequestMapping("/mobileNumWrite.do")
	public String mobileNumWrite(MobileVO vo,ModelMap model) throws Exception {
		
		return "mobile/mobileNumWrite";
		
	}
	
	@RequestMapping("/mobileDelete.do")
	public String mobileDelete(MobileVO vo) throws Exception{
		int result = mobileService.deleteMobile(vo);
		
		String str = "";		
		if (result == 1) str = "ok";
		else str = "fail";
		
		return str;
	
	}
	
	
	
	
	
}
